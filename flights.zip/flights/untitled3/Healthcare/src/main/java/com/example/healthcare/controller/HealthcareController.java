package com.example.healthcare.controller;

import com.example.healthcare.dto.TicketRq;
import com.example.healthcare.entity.Flight;
import com.example.healthcare.entity.Passenger;
import com.example.healthcare.entity.Ticket;
import com.example.healthcare.repository.FlightRepository;
import com.example.healthcare.repository.PassengerRepository;
import com.example.healthcare.repository.TicketRepository;
import com.example.healthcare.service.FlightService;
import com.example.healthcare.service.PassengerService;
import com.example.healthcare.service.TicketService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@RestController
@RequestMapping("")
@RequiredArgsConstructor
public class HealthcareController {
    private final FlightService flightService;
    private final PassengerService passengerService;
    private final TicketService ticketService;
    private final TicketRepository ticketRepository;
    private final FlightRepository flightRepository;
    private final PassengerRepository passengerRepository;

    @PostMapping("/tickets")
    public ResponseEntity<?> ticket(@Valid @RequestBody TicketRq ticketRq) {
        try {
            Ticket ticket = ticketService.createTicket(ticketRq);
        return ResponseEntity.status(HttpStatus.CREATED).body(ticket);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка при создании билета");
        }
    }

    @DeleteMapping ("tickets/{ticketId}")
    public void deleteTicket(@PathVariable("ticketId") Long ticketId) {
        ticketRepository.deleteById(ticketId);
    }

    @GetMapping("tickets/{passengerId}")
    public ResponseEntity<Object> getTickets(@PathVariable("passengerId") Long passengerId) {
        try {
            Passenger passenger = passengerService.getPassengerById(passengerId);
            if (passenger != null) {
                List<Ticket> tickets = ticketService.getTicketsByPassenger(passenger);
                List<Flight> flights = new ArrayList<>(Collections.emptyList());
                for (var ticket: tickets) {
                    flights.add(ticket.getFlight());
                }
                return ResponseEntity.ok(flights);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка при получении информации о билетах");
        }
    }
    @GetMapping("/flights")
    public ResponseEntity<?> getFlights() {
        var flights = flightRepository.findAll();
        return ResponseEntity.ok(flights);
    }

}