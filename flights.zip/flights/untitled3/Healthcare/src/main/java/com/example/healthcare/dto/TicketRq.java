package com.example.healthcare.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TicketRq {
    @NotBlank(message = "Field 'passengerId' is empty")
    private Long passengerId;
    @NotBlank(message = "Field 'flightId' is empty")
    private Long flightId;
}
