package com.example.healthcare.service;

import com.example.healthcare.dto.TicketRq;
import com.example.healthcare.entity.Passenger;
import com.example.healthcare.entity.Ticket;
import com.example.healthcare.repository.FlightRepository;
import com.example.healthcare.repository.PassengerRepository;
import com.example.healthcare.repository.TicketRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.nio.file.AccessDeniedException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TicketService {

    private final TicketRepository ticketRepository;
    private final PassengerRepository passengerRepository;
    private final FlightRepository flightRepository;

    public Ticket createTicket(TicketRq ticketRq) throws AccessDeniedException {
        if (passengerRepository.findById(ticketRq.getPassengerId()).isEmpty()) {
            throw new AccessDeniedException("Пассажир не найден");
        }
        if  (flightRepository.findById(ticketRq.getFlightId()).isEmpty()) {
            throw new AccessDeniedException("Рейс не найден");
        }

        Ticket ticket = new Ticket();
        ticket.setPassenger(passengerRepository.findById(ticketRq.getPassengerId()).orElse(null));
        ticket.setFlight(flightRepository.findById(ticketRq.getFlightId()).orElse(null));

        return ticketRepository.save(ticket);
    }


    public List<Ticket> getTicketsByPassenger(Passenger passenger) {
        return ticketRepository.findByPassenger(passenger);
    }
}
